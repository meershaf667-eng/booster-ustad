@echo off
title Booster Ustad - band karne ke liye ye window close kar dein
cd /d "%~dp0"
echo.
echo  ================================================
echo   Booster Ustad start ho raha hai...
echo   4 second mein browser mein app khul jayegi.
echo.
echo   BAND karne ke liye ye kali window close kar dein.
echo  ================================================
echo.
start /min "" cmd /c "timeout /t 4 /nobreak >nul & start http://localhost:3000"
node.exe server.js
